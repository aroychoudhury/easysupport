package org.abhishek.easysupport.dto.rest;

public interface Restful {

}
